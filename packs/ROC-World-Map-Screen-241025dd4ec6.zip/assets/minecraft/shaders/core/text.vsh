#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif

#ifdef IS_GUI
    // ROC XP timer glyphs alone use these exact vertex colour tags.
    ivec3 tag = ivec3(round(Color.rgb * 255.0));
    if (tag == ivec3(13, 251, 219) || tag == ivec3(21, 251, 223) || tag == ivec3(25, 251, 215)) {
        // The original GUI text uses the action-bar origin (width/2, height-72). The first timer starts at y=-69.
        gl_Position.xy += vec2(ProjMat[3][0], 2.0 * ProjMat[3][1] + 144.0 * ProjMat[1][1]) * gl_Position.w;
        if (tag.r == 13) vertexColor.rgb = vec3(1.0);
        else if (tag.r == 21) vertexColor.rgb = vec3(0.75, 0.91, 0.92);
        else vertexColor.rgb = vec3(1.0, 0.83, 0.52);
    }
#endif
    texCoord0 = UV0;
}
